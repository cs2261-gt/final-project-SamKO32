
//{{BLOCK(mordecaiHead)

//======================================================================
//
//	mordecaiHead, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 32 + 32768 = 32800
//
//	Time-stamp: 2020-04-05, 17:27:50
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MORDECAIHEAD_H
#define GRIT_MORDECAIHEAD_H

#define mordecaiHeadTilesLen 32768
extern const unsigned short mordecaiHeadTiles[16384];

#define mordecaiHeadPalLen 32
extern const unsigned short mordecaiHeadPal[16];

#endif // GRIT_MORDECAIHEAD_H

//}}BLOCK(mordecaiHead)
