
//{{BLOCK(gbfLose)

//======================================================================
//
//	gbfLose, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 311 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 19904 + 2048 = 22464
//
//	Time-stamp: 2020-04-02, 07:43:46
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GBFLOSE_H
#define GRIT_GBFLOSE_H

#define gbfLoseTilesLen 19904
extern const unsigned short gbfLoseTiles[9952];

#define gbfLoseMapLen 2048
extern const unsigned short gbfLoseMap[1024];

#define gbfLosePalLen 512
extern const unsigned short gbfLosePal[256];

#endif // GRIT_GBFLOSE_H

//}}BLOCK(gbfLose)
